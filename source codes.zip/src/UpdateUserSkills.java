import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateUserSkills extends Frame 
{
	Button usB;
	List usList;
	TextField skidTf, euidTf, sinceTf;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	Label name;
	public UpdateUserSkills() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadUs() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT SKID FROM user_skill");
		  while (rs.next()) 
		  {
			usList.add(rs.getString("SKID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{
		name= new Label("Skill ID's");
	    usList = new List(10);
		loadUs();
		add(name);
		add(usList);
		
		
		usList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM user_skill where SKID ="+usList.getSelectedItem());
					rs.next();
					euidTf.setText(rs.getString("EUID"));
					skidTf.setText(rs.getString("SKID"));
					sinceTf.setText(rs.getString("SINCE"));					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		usB = new Button("Update User's Skill");
		usB.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE user_skill "
					+ "SET euid=" + euidTf.getText() + ", "
					+ "since ='"+ sinceTf.getText() + "' WHERE skid = "
					+ usList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					usList.removeAll();
					loadUs();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		skidTf = new TextField(15);
		skidTf.setEditable(false);
		euidTf = new TextField(15);
		sinceTf = new TextField(15);
				
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Skill ID:"));
		first.add(skidTf);
		first.add(new Label("User ID:"));
		first.add(euidTf);
		first.add(new Label("Since:"));
		first.add(sinceTf);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(usB);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update User's Skill");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateUserSkills uus = new UpdateUserSkills();

		uus.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		uus.buildGUI();
	}
}
