import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteCompanyRequirement extends Frame 
{
	Button crB;
	List crList;
	TextField cidTf,ridTf,prefTf;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	Label name;
	
	public DeleteCompanyRequirement() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadCr() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM cmp_req");
		  while (rs.next()) 
		  {
			crList.add(rs.getString("REQ_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{
		name = new Label("Requirement ID's");
	    crList = new List(10);
		loadCr();
		add(name);
		add(crList);
		
		
		crList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM cmp_req");
					while (rs.next()) 
					{
						if (rs.getString("REQ_ID").equals(crList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						cidTf.setText(rs.getString("CMP_ID"));
						ridTf.setText(rs.getString("REQ_ID"));
						prefTf.setText(rs.getString("SINCE"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		crB = new Button("Delete Company's Requirement");
		crB.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM cmp_req WHERE REQ_ID = "
							+ crList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					cidTf.setText(null);
					ridTf.setText(null);
					prefTf.setText(null);
					crList.removeAll();
					loadCr();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		ridTf = new TextField(15);
		cidTf = new TextField(15);
		prefTf = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Req ID:"));
		first.add(ridTf);
		first.add(new Label("Company ID:"));
		first.add(cidTf);
		first.add(new Label("Preference:"));
		first.add(prefTf);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(crB);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("To Delete Company's Requirement");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteCompanyRequirement dcr= new DeleteCompanyRequirement();

		dcr.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dcr.buildGUI();
	}
}
