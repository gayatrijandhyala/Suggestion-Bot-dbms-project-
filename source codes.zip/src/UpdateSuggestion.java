import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateSuggestion extends Frame 
{
	Button SuggB;
	List suggList;
	TextField midTf, sgskillTf, sglevelTf, uidTf;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateSuggestion() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadSugg() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT MID FROM suggestion");
		  while (rs.next()) 
		  {
			suggList.add(rs.getString("MID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    suggList = new List(10);
		loadSugg();
		add(suggList);
		
		
		suggList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM suggestion where MID ="+suggList.getSelectedItem());
					rs.next();
					
					sgskillTf.setText(rs.getString("SGSKILL"));
					sglevelTf.setText(rs.getString("SGLEVEL"));
					midTf.setText(rs.getString("MID"));
					uidTf.setText(rs.getString("U_ID"));
					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
		SuggB = new Button("Update Suggestion");
		SuggB.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE suggestion "
					+ "SET sgskill='" + sgskillTf.getText() + "',"
					+ "sglevel='" + sglevelTf.getText() + "', "
					+ "u_id ="+ uidTf.getText() + " WHERE mid = "
					+ suggList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					suggList.removeAll();
					loadSugg();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		midTf = new TextField(15);
		midTf.setEditable(false);
		sgskillTf = new TextField(15);
		sglevelTf = new TextField(15);
		uidTf = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Suggestion ID:"));
		first.add(midTf);
		first.add(new Label("Skill Name:"));
		first.add(sgskillTf);
		first.add(new Label("Skill Level:"));
		first.add(sglevelTf);
		first.add(new Label("User ID:"));
		first.add(uidTf);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(SuggB);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("To update Suggestions");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateSuggestion ups = new UpdateSuggestion();

		ups.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		ups.buildGUI();
	}
}
