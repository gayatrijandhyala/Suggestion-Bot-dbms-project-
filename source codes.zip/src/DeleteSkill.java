import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteSkill extends Frame 
{
	Button SkillB;
	List skillList;
	TextField skidTf, sknameTf, sklevelTf;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteSkill() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadSkill() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM skill");
		  while (rs.next()) 
		  {
			skillList.add(rs.getString("SKID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    skillList = new List(10);
		loadSkill();
		add(skillList);
		
		
		skillList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM skill");
					while (rs.next()) 
					{
						if (rs.getString("SKID").equals(skillList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						skidTf.setText(rs.getString("SKID"));
						sknameTf.setText(rs.getString("SKNAME"));
						sklevelTf.setText(rs.getString("SKLEVEL"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
		SkillB = new Button("Delete Skill");
		SkillB.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM skill WHERE SKID = "
							+ skillList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					skidTf.setText(null);
					sknameTf.setText(null);
					sklevelTf.setText(null);
					
					skillList.removeAll();
					loadSkill();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		skidTf = new TextField(15);
		sknameTf = new TextField(15);
		sklevelTf = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Skill ID:"));
		first.add(skidTf);
		first.add(new Label("Skill Name:"));
		first.add(sknameTf);
		first.add(new Label("Skill Level:"));
		first.add(sklevelTf);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(SkillB);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("To Delete Skills");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteSkill dels = new DeleteSkill();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}
