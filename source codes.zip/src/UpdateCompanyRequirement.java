import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateCompanyRequirement extends Frame 
{
	Button crB;
	List crList;
	TextField cidTf,ridTf,prefTf;
	TextArea errorText;
	Label name;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateCompanyRequirement() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadCr() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT REQ_ID FROM cmp_req");
		  while (rs.next()) 
		  {
			crList.add(rs.getString("REQ_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		name = new Label("Requirement ID's");
	    crList = new List(10);
		loadCr();
		add(name);
		add(crList);
		crList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM cmp_req where REQ_ID ="+crList.getSelectedItem());
					rs.next();
					cidTf.setText(rs.getString("CMP_ID"));
					ridTf.setText(rs.getString("REQ_ID"));
					prefTf.setText(rs.getString("SINCE"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
		crB = new Button("Update Company's Requirements");
		crB.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE cmp_req "
					+ "SET cmp_id=" + cidTf.getText() + ","
					+ "since='" + prefTf.getText() + "'WHERE req_id = "
					+ crList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					crList.removeAll();
					loadCr();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		ridTf = new TextField(15);
		ridTf.setEditable(false);
		cidTf = new TextField(15);
		prefTf = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Req ID:"));
		first.add(ridTf);
		first.add(new Label("Company ID:"));
		first.add(cidTf);
		first.add(new Label("Since:"));
		first.add(prefTf);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(crB);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Updation of Company's Requirement");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateCompanyRequirement ucr= new UpdateCompanyRequirement();

		ucr.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		ucr.buildGUI();
	}
}
