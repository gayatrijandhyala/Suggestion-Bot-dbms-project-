import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertRequiredSuggestion extends Frame 
{
	Button iurB;
	TextField midTf, dayTf, skidTf, ridTf;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertRequiredSuggestion() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		
		iurB = new Button("Insert Required Suggestions ");
		iurB.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  				  
				  String query= "INSERT INTO req_sugg VALUES(" + midTf.getText() +  ",'"+ dayTf.getText() + "'," + skidTf.getText() + ","+ridTf.getText()+")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		midTf = new TextField(15);
		dayTf = new TextField(15);
		skidTf = new TextField(15);
		ridTf = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Suggestion ID:"));
		first.add(midTf);
		first.add(new Label("Day:"));
		first.add(dayTf);
		first.add(new Label("Skill ID:"));
		first.add(skidTf);
		first.add(new Label("Req ID:"));
		first.add(ridTf);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(iurB);
        second.setBounds(205,220,200,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setTitle("Insert Required Suggestions");
		setSize(500, 600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertRequiredSuggestion irs = new InsertRequiredSuggestion();

		irs.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		irs.buildGUI();
	}
}
