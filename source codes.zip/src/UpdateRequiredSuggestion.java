import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateRequiredSuggestion extends Frame 
{
	Button rsB;
	List rsList;
	TextField midTf,dayTf,ridTf,skidTf;
	TextArea errorText;
	Label name;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateRequiredSuggestion() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadRs() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT SUGG_ID FROM req_sugg");
		  while (rs.next()) 
		  {
			rsList.add(rs.getString("SUGG_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		name = new Label("Suggestion ID's");
	    rsList = new List(10);
		loadRs();
		add(name);
		add(rsList);
		rsList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM req_sugg where SUGG_ID ="+rsList.getSelectedItem());
					rs.next();
					midTf.setText(rs.getString("SUGG_ID"));
					dayTf.setText(rs.getString("SINCE"));
					skidTf.setText(rs.getString("SKILL_ID"));
					ridTf.setText(rs.getString("REQS_ID"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
		rsB = new Button("Update Required Suggestion");
		rsB.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE req_sugg "
					+ "SET since='" + dayTf.getText() + "',"
					+ "skill_id=" + skidTf.getText() +","+ "reqs_id="+ridTf.getText()+ "WHERE sugg_id = "
					+ rsList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					rsList.removeAll();
					loadRs();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		midTf = new TextField(15);
		midTf.setEditable(false);
		dayTf = new TextField(15);
		skidTf = new TextField(15);
		ridTf = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Suggestion ID:"));
		first.add(midTf);
		first.add(new Label("Day:"));
		first.add(dayTf);
		first.add(new Label("Skill ID:"));
		first.add(skidTf);
		first.add(new Label("Req ID:"));
		first.add(ridTf);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(rsB);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Updation of Required Suggestions");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateRequiredSuggestion urs= new UpdateRequiredSuggestion();

		urs.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		urs.buildGUI();
	}
}
