import java.awt.*;
import java.awt.event.*;

public class SuggestionBot extends Frame implements ActionListener
{
	String msg="";
	Label label;
	InsertUser iuser;
	UpdateUser uuser;
	DeleteUser duser;
	InsertSkill iskill;
	UpdateSkill uskill;
	DeleteSkill dskill;
	InsertCompany icmp;
	UpdateCompany ucmp;
	DeleteCompany dcmp;
	InsertRequirement ireq;
	UpdateRequirement ureq;
	DeleteRequirement dreq;
	InsertSuggestion isugg;
	UpdateSuggestion usugg;
	DeleteSuggestion dsugg;
	InsertUserSkills ius;
	UpdateUserSkills uus;
	DeleteUserSkills dus;
	InsertUserCompany iuc;
	UpdateUserCompany uuc;
	DeleteUserCompany duc;
	InsertCompanyRequirement icr;
	UpdateCompanyRequirement ucr;
	DeleteCompanyRequirement dcr;
	InsertRequiredSuggestion irs;
	UpdateRequiredSuggestion urs;
	DeleteRequiredSuggestion drs;
	
	SuggestionBot()
	{
		label = new Label();
		label.setAlignment(Label.CENTER);  
		label.setBounds(200,350,350,200); 			
		label.setText("Welcome to Suggestion Bot");
		add(label);
		
		
		setTitle("Suggestion Bot for Interview SKills Management"); 
		Color clr = new Color(100, 100, 150);
		setBackground(clr); 
		setFont(new Font("SansSerif", Font.BOLD, 24)); 
		setLayout(null);
		setSize(800, 800); 
		setVisible(true);
		
		//setting the menu bar 
		MenuBar mb = new MenuBar();
		setMenuBar(mb);
		
		//adding menu and menu items to menu bar
		Menu user = new Menu("Users");
		MenuItem it1,it2,it3;
		user.add(it1= new MenuItem("Insert Users"));
		user.add(it2= new MenuItem("Update Users"));
		user.add(it3= new MenuItem("Delete Users"));
		mb.add(user);
		
		Menu skills = new Menu("Skills");
		MenuItem it4,it5,it6;
		skills.add(it4=new MenuItem("Insert Skills"));
		skills.add(it5= new MenuItem("Update Skills"));
		skills.add(it6=new MenuItem("Delete Skills"));
		mb.add(skills);
		
		Menu cmp = new Menu("Companies");
		MenuItem it7,it8,it9;
		cmp.add(it7=new MenuItem("Insert Companies"));
		cmp.add(it8=new MenuItem("Update Companies"));
		cmp.add(it9=new MenuItem("Delete Companies"));
		mb.add(cmp);
		
		Menu req = new Menu("Requirements");
		MenuItem it10,it11,it12;
		req.add(it10=new MenuItem("Insert Requirements"));
		req.add(it11=new MenuItem("Update Requirements"));
		req.add(it12=new MenuItem("Delete Requirements"));
		mb.add(req);
		
		Menu sugg = new Menu("Suggestions");
		MenuItem it13,it14,it15;
		sugg.add(it13=new MenuItem("Insert Suggestions"));
		sugg.add(it14=new MenuItem("Update Suggestions"));
		sugg.add(it15=new MenuItem("Delete Suggestions"));
		mb.add(sugg);
		
		Menu us = new Menu("User's Skills");
		MenuItem i1,i2,i3;
		us.add(i1=new MenuItem("Insert User's Skills"));
		us.add(i2=new MenuItem("Update User's Skills"));
		us.add(i3=new MenuItem("Delete User's Skills"));
		mb.add(us);
		
		Menu uc = new Menu("User Company Choice");
		MenuItem i4,i5,i6;
		uc.add(i4=new MenuItem("Insert User's Company"));
		uc.add(i5=new MenuItem("Update User's Company"));
		uc.add(i6=new MenuItem("Delete User's Company"));
		mb.add(uc);
		
		Menu cr = new Menu("Company Requirements");
		MenuItem i7,i8,i9;
		cr.add(i7=new MenuItem("Insert Company Requirements"));
		cr.add(i8=new MenuItem("Update Company Requirements"));
		cr.add(i9=new MenuItem("Delete Company Requirements"));
		mb.add(cr);
		
		Menu rs = new Menu("Required Suggestions");
		MenuItem i10,i11,i12;
		rs.add(i10=new MenuItem("Insert Required Suggestions"));
		rs.add(i11=new MenuItem("Update Required Suggestions"));
		rs.add(i12=new MenuItem("Delete Required Suggestions"));
		mb.add(rs);
		
		//registering action listeners
		it1.addActionListener(this); 
		it2.addActionListener(this); 
		it3.addActionListener(this); 
		it4.addActionListener(this); 
		it5.addActionListener(this); 
		it6.addActionListener(this); 
		it7.addActionListener(this); 
		it8.addActionListener(this); 
		it9.addActionListener(this); 
		it10.addActionListener(this); 
		it11.addActionListener(this); 
		it12.addActionListener(this);
		it13.addActionListener(this);
		it14.addActionListener(this); 
		it15.addActionListener(this); 
		//entities above
		//relation tables below
		i1.addActionListener(this); 
		i2.addActionListener(this); 
		i3.addActionListener(this); 
		i4.addActionListener(this); 
		i5.addActionListener(this); 
		i6.addActionListener(this); 
		i7.addActionListener(this); 
		i8.addActionListener(this); 
		i9.addActionListener(this); 
		i10.addActionListener(this); 
		i11.addActionListener(this); 
		i12.addActionListener(this); 
		
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we) 
			{ 
				System.exit(0);	
			} 
		}); 
		
	}
	
	 public void actionPerformed(ActionEvent ae) 
	  { 

		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Insert Users"))
		  {
			iuser = new InsertUser();

			iuser.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				iuser.dispose();
			}
			});		
			iuser.buildGUI();	
         }			
		 
		 else if(arg.equals("Update Users")) 
		 {
			uuser = new UpdateUser();
			uuser.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				uuser.dispose();
			}
			});		
			uuser.buildGUI();		 
		 }
		 else if(arg.equals("Delete Users")) 
		 {
			duser = new DeleteUser();
			duser.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				duser.dispose();
			}
			});		
			duser.buildGUI();		 
		 }
		 else if(arg.equals("Insert Skills")) 
		 {
			iskill = new InsertSkill();
			iskill.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				iskill.dispose();
			}
			});		
			iskill.buildGUI();		 
		 }
		 else if(arg.equals("Update Skills")) 
		 {
			uskill = new UpdateSkill();
			uskill.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				uskill.dispose();
			}
			});		
			uskill.buildGUI();		 
		 }
		 else if(arg.equals("Delete Skills")) 
		 {
			dskill = new DeleteSkill();
			dskill.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				dskill.dispose();
			}
			});		
			dskill.buildGUI();		 
		 }
		 else if(arg.equals("Insert Companies")) 
		 {
			icmp = new InsertCompany();
			icmp.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				icmp.dispose();
			}
			});		
			icmp.buildGUI();		 
		 }
		 else if(arg.equals("Update Companies")) 
		 {
			ucmp = new UpdateCompany();
			ucmp.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				ucmp.dispose();
			}
			});		
			ucmp.buildGUI();		 
		 }
		 else if(arg.equals("Delete Companies")) 
		 {
			dcmp = new DeleteCompany();
			dcmp.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				dcmp.dispose();
			}
			});		
			dcmp.buildGUI();		 
		 }
		 else if(arg.equals("Insert Requirements")) 
		 {
			ireq = new InsertRequirement();
			ireq.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				ireq.dispose();
			}
			});		
			ireq.buildGUI();		 
		 }
		 else if(arg.equals("Update Requirements")) 
		 {
			ureq = new UpdateRequirement();
			ureq.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				ureq.dispose();
			}
			});		
			ureq.buildGUI();		 
		 }
		 else if(arg.equals("Delete Requirements")) 
		 {
			dreq = new DeleteRequirement();
			dreq.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				dreq.dispose();
			}
			});		
			dreq.buildGUI();		 
		 }
		 else if(arg.equals("Insert Suggestions")) 
		 {
			isugg = new InsertSuggestion();
			isugg.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				isugg.dispose();
			}
			});		
			isugg.buildGUI();		 
		 }
		 else if(arg.equals("Update Suggestions")) 
		 {
			usugg = new UpdateSuggestion();
			usugg.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				usugg.dispose();
			}
			});		
			usugg.buildGUI();		 
		 }
		 else if(arg.equals("Delete Suggestions")) 
		 {
			dsugg = new DeleteSuggestion();
			dsugg.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				dsugg.dispose();
			}
			});		
			dsugg.buildGUI();		 
		 }
		 else if(arg.equals("Insert User's Skills")) 
		 {
			ius = new InsertUserSkills();
			ius.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				ius.dispose();
			}
			});		
			ius.buildGUI();		 
		 }
		 else if(arg.equals("Update User's Skills")) 
		 {
			uus = new UpdateUserSkills();
			uus.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				uus.dispose();
			}
			});		
			uus.buildGUI();		 
		 }
		 else if(arg.equals("Delete User's Skills")) 
		 {
			dus = new DeleteUserSkills();
			dus.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				dus.dispose();
			}
			});		
			dus.buildGUI();		 
		 }
		 else if(arg.equals("Insert User's Company")) 
		 {
			iuc = new InsertUserCompany();
			iuc.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				iuc.dispose();
			}
			});		
			iuc.buildGUI();		 
		 }
		 else if(arg.equals("Update User's Company")) 
		 {
			uuc = new UpdateUserCompany();
			uuc.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				uuc.dispose();
			}
			});		
			uuc.buildGUI();		 
		 }
		 else if(arg.equals("Delete User's Company")) 
		 {
			duc = new DeleteUserCompany();
			duc.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				duc.dispose();
			}
			});		
			duc.buildGUI();		 
		 }
		 else if(arg.equals("Insert Company Requirements")) 
		 {
			icr = new InsertCompanyRequirement();
			icr.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				icr.dispose();
			}
			});		
			icr.buildGUI();		 
		 }
		 else if(arg.equals("Update Company Requirements")) 
		 {
			ucr = new UpdateCompanyRequirement();
			ucr.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				ucr.dispose();
			}
			});		
			ucr.buildGUI();		 
		 }
		 else if(arg.equals("Delete Company Requirements")) 
		 {
			dcr = new DeleteCompanyRequirement();
			dcr.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				dcr.dispose();
			}
			});		
			dcr.buildGUI();		 
		 }
		 else if(arg.equals("Insert Required Suggestions")) 
		 {
			irs = new InsertRequiredSuggestion();
			irs.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				irs.dispose();
			}
			});		
			irs.buildGUI();		 
		 }
		 else if(arg.equals("Update Required Suggestions")) 
		 {
			urs = new UpdateRequiredSuggestion();
			urs.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				urs.dispose();
			}
			});		
			urs.buildGUI();		 
		 }
		 else if(arg.equals("Delete Required Suggestions")) 
		 {
			drs = new DeleteRequiredSuggestion();
			drs.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				drs.dispose();
			}
			});		
			drs.buildGUI();		 
		 }
	}
	
	public static void main(String[] args)
	{
		new SuggestionBot();
	}

}