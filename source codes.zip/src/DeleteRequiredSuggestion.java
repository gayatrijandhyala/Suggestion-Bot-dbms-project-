import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteRequiredSuggestion extends Frame 
{
	Button rsB;
	List rsList;
	TextField midTf,sinceTf,skidTf,ridTf;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	Label name;
	
	public DeleteRequiredSuggestion() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadRs() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM req_sugg");
		  while (rs.next()) 
		  {
			rsList.add(rs.getString("SUGG_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{
		name = new Label("Suggestion ID's");
	    rsList = new List(10);
		loadRs();
		add(name);
		add(rsList);
		
		
		rsList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM req_sugg");
					while (rs.next()) 
					{
						if (rs.getString("SUGG_ID").equals(rsList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						midTf.setText(rs.getString("SUGG_ID"));
						sinceTf.setText(rs.getString("SINCE"));
						skidTf.setText(rs.getString("SKILL_ID"));
						ridTf.setText(rs.getString("REQS_ID"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		rsB = new Button("Delete Required Suggestion");
		rsB.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM req_sugg WHERE SUGG_ID = "
							+ rsList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					midTf.setText(null);
					sinceTf.setText(null);
					skidTf.setText(null);
					ridTf.setText(null);
					rsList.removeAll();
					loadRs();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		midTf = new TextField(15);
		sinceTf = new TextField(15);
		skidTf = new TextField(15);
		ridTf = new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Suggestion ID:"));
		first.add(midTf);
		first.add(new Label("Since:"));
		first.add(sinceTf);
		first.add(new Label("Skill ID:"));
		first.add(skidTf);
		first.add(new Label("Req ID:"));
		first.add(ridTf);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(rsB);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("To Delete Required Suggestion");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteRequiredSuggestion drs = new DeleteRequiredSuggestion();

		drs.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		drs.buildGUI();
	}
}
