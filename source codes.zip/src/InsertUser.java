import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertUser extends Frame 
{
	Button UserB;
	TextField euidTf, eunameTf, emailidTf;
	TextArea errorText;
	Connection conn;
	Statement st;
	//constructor
	public InsertUser() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}
//to add and initialize items to frame 
	public void buildGUI() 
	{		
		UserB = new Button("Insert User");
		UserB.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{			  
				  String query= "INSERT INTO enduser VALUES(" + euidTf.getText() + ", " + "'" + eunameTf.getText() + "'," +"'"+ emailidTf.getText() +"'"+ ")";
				  int i = st.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		euidTf = new TextField(15);
		eunameTf = new TextField(15);
		emailidTf = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("User ID:"));
		first.add(euidTf);
		first.add(new Label("Name:"));
		first.add(eunameTf);
		first.add(new Label("Email ID:"));
		first.add(emailidTf);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(UserB);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setTitle("To Insert New Users");
		setSize(500, 600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public void connectToDB() 
    {
		try 
		{
		  conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  st = conn.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }	

	public static void main(String[] args) 
	{
		InsertUser user = new InsertUser();

		user.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		user.buildGUI();
	}
}