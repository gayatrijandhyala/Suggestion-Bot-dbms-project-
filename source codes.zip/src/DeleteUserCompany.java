import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteUserCompany extends Frame 
{
	Button ucB;
	List ucList;
	TextField cidTf,uidTf,prefTf;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	Label name;
	
	public DeleteUserCompany() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadUc() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM user_company");
		  while (rs.next()) 
		  {
			ucList.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{
		name = new Label("Company ID's");
	    ucList = new List(10);
		loadUc();
		add(name);
		add(ucList);
		
		
		ucList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM user_company");
					while (rs.next()) 
					{
						if (rs.getString("CID").equals(ucList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						cidTf.setText(rs.getString("CID"));
						uidTf.setText(rs.getString("USER_ID"));
						prefTf.setText(rs.getString("PREFERENCE"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		ucB = new Button("Delete User's Choice of Company");
		ucB.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM user_company WHERE CID = "
							+ ucList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					cidTf.setText(null);
					uidTf.setText(null);
					prefTf.setText(null);
					ucList.removeAll();
					loadUc();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidTf = new TextField(15);
		uidTf = new TextField(15);
		prefTf = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Company ID:"));
		first.add(cidTf);
		first.add(new Label("User ID:"));
		first.add(uidTf);
		first.add(new Label("Preference:"));
		first.add(prefTf);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(ucB);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("To Delete User's Choice of Company");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteUserCompany duc= new DeleteUserCompany();

		duc.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		duc.buildGUI();
	}
}
