import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateSkill extends Frame 
{
	Button SkillB;
	List skillList;
	TextField skidTf, sknameTf, sklevelTf;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateSkill() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadSkill() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT SKID FROM skill");
		  while (rs.next()) 
		  {
			skillList.add(rs.getString("SKID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    skillList = new List(10);
		loadSkill();
		add(skillList);
		
		
		skillList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM skill where SKID ="+skillList.getSelectedItem());
					rs.next();
					skidTf.setText(rs.getString("SKID"));
					sknameTf.setText(rs.getString("SKNAME"));
					sklevelTf.setText(rs.getString("SKLEVEL"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		SkillB = new Button("Update Skill");
		SkillB.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE skill "
					+ "SET skname='" + sknameTf.getText() + "',"
					+ "sklevel='" + sklevelTf.getText() + "' WHERE skid = "
					+ skillList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					skillList.removeAll();
					loadSkill();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		skidTf = new TextField(15);
		skidTf.setEditable(false);
		sknameTf = new TextField(15);
		sklevelTf = new TextField(15);

		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Skill ID:"));
		first.add(skidTf);
		first.add(new Label("Skill Name:"));
		first.add(sknameTf);
		first.add(new Label("Skill Level:"));
		first.add(sklevelTf);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(SkillB);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("To Update Skills");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateSkill ups = new UpdateSkill();

		ups.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		ups.buildGUI();
	}
}
