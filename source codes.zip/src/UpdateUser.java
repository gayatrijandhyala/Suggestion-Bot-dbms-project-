import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateUser extends Frame 
{
	Button UserB;
	List userList;
	TextField euidTf, eunameTf, emailidTf;
	TextArea errorText;
	Connection conn;
	Statement st;
	ResultSet rs;
	
	public UpdateUser() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Cannot find and load driver");
			System.exit(1);
		}
		connectToDB();
	}
	
	private void loadUser() 
	{	   
		try 
		{
		  rs = st.executeQuery("SELECT EUID FROM enduser");
		  while (rs.next()) 
		  {
			userList.add(rs.getString("EUID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    userList = new List(10);
		loadUser();
		add(userList);
		
		userList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = st.executeQuery("SELECT * FROM enduser where EUID ="+userList.getSelectedItem());
					rs.next();
					euidTf.setText(rs.getString("EUID"));
					eunameTf.setText(rs.getString("EUNAME"));
					emailidTf.setText(rs.getString("EUEMAIL_ID"));
					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		UserB= new Button("Update User");
		UserB.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = conn.createStatement();
					int i = statement.executeUpdate("UPDATE enduser "
					+ "SET euname='" + eunameTf.getText() + "', "
					+ "euemail_id='" + emailidTf.getText() + "'WHERE euid = "
					+ userList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					userList.removeAll();
					loadUser();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		euidTf = new TextField(15);
		euidTf.setEditable(false);
		eunameTf = new TextField(15);
		emailidTf = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("User ID:"));
		first.add(euidTf);
		first.add(new Label("Name:"));
		first.add(eunameTf);
		first.add(new Label("Email ID:"));
		first.add(emailidTf);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(UserB);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("To Update Users");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}
	public void connectToDB() 
    {
		try 
		{
		  conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gayatri","manager");
		  st = conn.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateUser upUs = new UpdateUser();

		upUs.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		upUs.buildGUI();
	}
}
